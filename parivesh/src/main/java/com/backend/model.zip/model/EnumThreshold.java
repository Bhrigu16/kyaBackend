package com.backend.model;

public enum EnumThreshold {
	HA,//0
	KM,//1
	MW,//2
	Ha,//3
	Km,//4
	No,//5
	NA,//6
	Kg,//7
	MTPA,//8
	TPA,//9
	KLD,//10
	TCD,//11
	PassengersPA,//12
	sqmtr,//13
	mtr//14
}
